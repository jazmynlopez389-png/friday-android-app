package com.example.friday

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Night = Color(0xFF070D18)
private val Panel = Color(0xFF101D30)
private val Cyan = Color(0xFF55DFFF)
private val Muted = Color(0xFF91A9BE)

// Set this to your deployed HTTPS server address. Do not put an AI provider key in the app.
private const val FRIDAY_SERVER_URL = "https://YOUR-SERVER.example.com"

data class ChatMessage(val text: String, val fromFriday: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            FridayApp(
                onSpeak = { speak(it) },
                onVoiceChoice = { pitch, rate ->
                    tts?.setPitch(pitch)
                    tts?.setSpeechRate(rate)
                }
            )
        }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.setSpeechRate(0.94f)
            tts?.setPitch(0.92f)
        }
    }
    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "friday_reply")
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun FridayApp(onSpeak: (String) -> Unit, onVoiceChoice: (Float, Float) -> Unit) {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf(ChatMessage("Good evening. FRIDAY systems are online. How may I assist you?", true))) }
    var status by remember { mutableStateOf("SYSTEMS ONLINE") }
    var reminder by remember { mutableStateOf("") }
    var showReminder by remember { mutableStateOf(false) }
    var showVoice by remember { mutableStateOf(false) }
    var voiceStyle by remember { mutableStateOf("Calm") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) input = spoken
        }
    }

    fun sendMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty() || busy) return
        val nextMessages = messages + ChatMessage(prompt, false)
        messages = nextMessages
        input = ""
        busy = true
        status = "THINKING"
        scope.launch {
            val reply = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                requestFridayReply(nextMessages)
            }
            messages = messages + ChatMessage(reply, true)
            busy = false
            status = "SYSTEMS ONLINE"
            onSpeak(reply)
        }
    }

    if (showReminder) {
        AlertDialog(onDismissRequest = { showReminder = false },
            title = { Text("New reminder", color = Cyan) },
            text = { OutlinedTextField(value = reminder, onValueChange = { reminder = it }, label = { Text("What should FRIDAY remind you about?") }) },
            confirmButton = { TextButton(onClick = {
                if (reminder.isNotBlank()) messages = messages + ChatMessage("Reminder saved in this session: $reminder. Device notification scheduling is not enabled yet.", true)
                reminder = ""; showReminder = false
            }) { Text("SAVE", color = Cyan) } },
            dismissButton = { TextButton(onClick = { showReminder = false }) { Text("CANCEL") } },
            containerColor = Panel
        )
    }
    if (showVoice) {
        AlertDialog(onDismissRequest = { showVoice = false },
            title = { Text("FRIDAY voice profile", color = Cyan) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Choose a built-in Android voice style. Available voices depend on your device's installed speech engine.", color = Color.White)
                    listOf("Calm", "Bright", "Deep").forEach { choice ->
                        Row(Modifier.fillMaxWidth().clickable {
                            voiceStyle = choice
                            when (choice) {
                                "Bright" -> onVoiceChoice(1.08f, 1.02f)
                                "Deep" -> onVoiceChoice(0.82f, 0.90f)
                                else -> onVoiceChoice(0.92f, 0.94f)
                            }
                        }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = voiceStyle == choice, onClick = {
                                voiceStyle = choice
                                when (choice) {
                                    "Bright" -> onVoiceChoice(1.08f, 1.02f)
                                    "Deep" -> onVoiceChoice(0.82f, 0.90f)
                                    else -> onVoiceChoice(0.92f, 0.94f)
                                }
                            })
                            Text(choice, color = Color.White)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showVoice = false }) { Text("DONE", color = Cyan) } },
            containerColor = Panel
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Night, surface = Panel, onPrimary = Night, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0D1C30), Night))).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("STARK-STYLE PERSONAL AI", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    Text("FRIDAY", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                }
                Box(Modifier.size(12.dp).background(Cyan, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(status, color = Cyan, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().height(150.dp).border(1.dp, Cyan.copy(alpha = .55f), RoundedCornerShape(18.dp)).background(Color(0xFF0A1728), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(82.dp).border(2.dp, Cyan, CircleShape).padding(8.dp).border(1.dp, Cyan.copy(alpha=.5f), CircleShape), contentAlignment = Alignment.Center) {
                        Text("F", color = Cyan, fontSize = 36.sp, fontWeight = FontWeight.Light)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(if (busy) "PROCESSING REQUEST…" else "VOICE INTERFACE • READY", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatusTile("AI CORE", if (busy) "ACTIVE" else "READY", Modifier.weight(1f))
                StatusTile("VOICE", voiceStyle.uppercase(), Modifier.weight(1f))
                StatusTile("NETWORK", if (FRIDAY_SERVER_URL.contains("YOUR-SERVER")) "SETUP" else "HTTPS", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("CONVERSATION", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
                Text("VOICE", color = Cyan, fontSize = 10.sp, modifier = Modifier.clickable { showVoice = true }.padding(end = 14.dp))
                Text("CLEAR", color = Cyan, fontSize = 10.sp, modifier = Modifier.clickable { messages = emptyList() })
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromFriday) Arrangement.Start else Arrangement.End) {
                        Column(Modifier.widthIn(max = 300.dp).background(if (msg.fromFriday) Panel else Color(0xFF12344A), RoundedCornerShape(14.dp)).padding(12.dp)) {
                            Text(if (msg.fromFriday) "FRIDAY" else "YOU", color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(msg.text, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask FRIDAY anything…", color = Muted) }, singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan))
                Spacer(Modifier.width(6.dp))
                IconButton(onClick = {
                    status = "LISTENING"
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to FRIDAY")
                    }
                    try { speechLauncher.launch(intent) } catch (_: Exception) { status = "VOICE UNAVAILABLE" }
                }) { Text("🎙", fontSize = 22.sp) }
                Button(onClick = { sendMessage() }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                    Text("SEND", color = Night, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { showReminder = true }, modifier = Modifier.weight(1f)) { Text("＋ REMINDERS", color = Cyan, fontSize = 10.sp) }
                OutlinedButton(onClick = { showVoice = true }, modifier = Modifier.weight(1f)) { Text("♫ VOICE", color = Cyan, fontSize = 10.sp) }
            }
            Spacer(Modifier.height(5.dp))
            Text("AI requires your private backend to be deployed and configured.", color = Muted, fontSize = 9.sp)
        }
    }
}

private fun requestFridayReply(messages: List<ChatMessage>): String {
    if (FRIDAY_SERVER_URL.contains("YOUR-SERVER")) return "I'm ready to think, but my secure AI connection has not been configured yet. Follow the server setup in the project README."
    var connection: HttpURLConnection? = null
    return try {
        val url = URL("${FRIDAY_SERVER_URL.trimEnd('/')}/chat")
        connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val history = JSONArray()
        messages.takeLast(16).forEach { msg ->
            history.put(JSONObject().put("role", if (msg.fromFriday) "assistant" else "user").put("content", msg.text))
        }
        val body = JSONObject().put("messages", history).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        val json = JSONObject(response)
        json.optString("reply").ifBlank { json.optString("error", "FRIDAY could not complete that request.") }
    } catch (_: Exception) {
        "I can't reach my AI server right now. Please check the connection and try again."
    } finally { connection?.disconnect() }
}

@Composable
fun StatusTile(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(10.dp)).padding(10.dp)) {
        Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
